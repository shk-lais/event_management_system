<?php

    include "conn.php";

    $token = uniqid();
    $approval = "pending";
    $evnt_name = "seminar";


    if($_POST['submit'])
    {
        $title=$_POST['title'];
        $name=$_POST['name'];
        $email=$_POST['email'];
        $number=$_POST['number'];
        $date=$_POST['date'];
        $address=$_POST['address'];
        $choice=$_POST['choice'];
        $requst=$_POST['request'];

        
        $sql="INSERT INTO seminar VALUES('$title','$name','$email','$number','$date','$address','$choice','$requst','$token','$approval','$evnt_name');";
       // echo $sql;

        $result = mysqli_query($conn,$sql)or die("Connection failed: " .mysqli_error());
        
        if($result) {
            echo "<script>alert('Your form has been submitted.'); window.location.href = 'view.php';</script>";
           // echo "inside";
        }
        else{
            echo "<script>alert('Your form is not submitted.'); window.location.href = 'seminar_form.php';</script>";
        }
    }

?>