<?php
//error_reporting(0);
    $server = "localhost";
    $user = "root";
    $password = "mysql1234";
    $dbname = "project";

    $conn=mysqli_connect($server,$user,$password,$dbname);

    if (!$conn) {
        echo "Connection failed: ".mysqli_connect_error();
    }
    // else{
    //     echo "connected";
    // }

?>