<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="css/dataTables.bootstrap5.min.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">
    <title>Dashboard</title>
  </head>
  <body>
    <!-- top navigation bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container-fluid">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="offcanvas"
          data-bs-target="#sidebar"
          aria-controls="offcanvasExample">
          <span class="navbar-toggler-icon" data-bs-target="#sidebar"></span>
        </button>
        <a
          class="navbar-brand me-auto ms-lg-0 ms-3 text-uppercase fw-bold"
          href="adminhome.php">MyEvent</a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#topNavBar"
          aria-controls="topNavBar"
          aria-expanded="false"
          aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      </div>
    </nav>
    <!-- top navigation bar -->
    <!-- offcanvas -->
    <div
      class="offcanvas offcanvas-start sidebar-nav bg-dark"
      tabindex="-1"
      id="sidebar">
      <div class="offcanvas-body p-0">
        <nav class="navbar-dark">
          <ul class="navbar-nav">
           <br>
            <li>
              <a href="adminhome.php" class="nav-link px-3 active">
                <span class="me-2"><i class="bi bi-speedometer2"></i></span>
                <span>Dashboard</span>
              </a>
            </li>
            <li>
              <a href="vendor.php" class="nav-link px-3 active">
                <span class="me-2"><i class="bi bi-people-fill"></i></span>
                <span>Vendor</span>
              </a>
            </li>
            <li>
              <a href="user.php" class="nav-link px-3 active">
                <span class="me-2"><i class="bi bi-people-fill"></i></span>
                <span>User</span>
              </a>
            </li>
            <br>
            <li>
              <a href="delete.php" class="nav-link px-3 active">
                <span class="me-2"><i class="bi bi-person-dash"></i></span>
                <span>Delete</span>
              </a>
            </li>
            <li>
              <a href="delete_evnt.php" class="nav-link px-3 active">
                <span class="me-2"><i class="bi bi-calendar-x"></i></span>
                <span>Delete Event</span>
              </a>
            </li>
            <br>
            <li>
              <a href="complain.php" class="nav-link px-3 active">
                <span class="me-2"><i class="bi bi-chat-left-text"></i></span>
                <span>Complain</span>
              </a>
            </li>
            <br><br>
            <li>
              <a href="logout.php" class="nav-link px-3">
                <span class="me-2"><i class="bi bi-box-arrow-right"></i></span>
                <span>Logout</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </div>
    <!-- offcanvas -->
    <main class="mt-5 pt-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white h-100">
              <div class="card-body py-5">Birthday Event</div>
              <div class="card-footer d-flex">
                <a href="bd_detail.php">View Details</a>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white h-100">
              <div class="card-body py-5">Wedding Events</div>
              <div class="card-footer d-flex">
              <a href="wed_detail.php">View Details</a>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white h-100">
              <div class="card-body py-5">Seminar Events</div>
              <div class="card-footer d-flex">
              <a href="semi_detail.php">View Details</a>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white h-100">
              <div class="card-body py-5">Anniversary Events</div>
              <div class="card-footer d-flex">
              <a href="anni_detail.php">View Details</a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-12 mb-3">
            <div class="card h-100">
              <div class="card-header">
                Delete Event
              </div>
              <div class="card-body">
              <?php

include "conn.php";

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['delete'])) {
        $token = $_POST['token'];
        $event = $_POST['name'];
        // echo $event;    


        if($event=='birthday'){
            $sql = "DELETE FROM `birthday` WHERE `token` = '$token';";
        }elseif($event=='wedding'){
            $sql = "DELETE FROM `wedding` WHERE `token` = '$token';";
        }elseif ($event == 'seminar') {
            $sql = "DELETE FROM `seminar` WHERE `token` = '$token';";
        }elseif ($event == 'anniversary') {
            $sql = "DELETE FROM `anniversary` WHERE `token` = '$token';";
        }


        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Event Deleted'); window.location.href = 'delete1.php';</script>";
        }else{
            echo "<script>alert('Event Delete Fail'); window.location.href = 'delete.php';</script>";
        }

    }
}
    ?>
              </div>
            </div>
          </div>
    </main>
    <!-- end main -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.0.2/dist/chart.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-3.5.1.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap5.min.js"></script>
  </body>
</html>
