<?php
    include "conn.php";
    include "chklogin.php";

    session_start();

    if($_POST['book']){
        if($_SESSION['login']=true){
            header("location:evnt_list.php");
            exit();
        }else{
            header("location:login.php");
        }
    }
?>