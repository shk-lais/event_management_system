<?php

  include "conn.php";

  $uid = uniqid();

  // getting value from form 
  if($_POST['submit'])
  {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $role=$_POST['role'];

    //password encryption
    //$password1 = password_hash($password, PASSWORD_DEFAULT);
    
    $sql="INSERT INTO register VALUES('$name','$email','$password','$role','$uid');";

    $result = mysqli_query($conn,$sql)or die("Connection failed: " .mysqli_error());
    
    if($result) {
      // echo "<html><script>alert('Register Successfull..! Please Login')</script></html>";
      // header('location:login.php');
      echo "<script>alert('Thank You for Registor..! Please Login.'); window.location.href = 'login.php';</script>";
    }
    else{
      echo "<script>alert('Register Unsuccessfull..! Please Try agian.'); window.location.href = 'index.php';</script>";
    }
  }
?>