<?php

require "conn.php";
require "chklogin.php";

session_start();

// $_SESSION = array();
session_unset();
session_destroy();
header("Location: login.php");
exit();


// session_start(); 

// if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
//     session_unset();
//     session_destroy();
//     header("Location: login.php");
//     exit;
// } else {
//     header("Location: login.php");
//     exit;
// }



?>