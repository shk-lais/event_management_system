<?php
    include "conn.php";

    if($_POST['submit'])
    {
        $password=$_POST['pasd'];
        $password1=$_POST['pasd1'];
        $email=$_POST['email'];

        if($password==$password1){

            $sql = "UPDATE register SET password = '$password' WHERE email = '$email';";

            $result=mysqli_query($conn,$sql) or die("Error in Query...");

            if($result){
                echo "<script>alert('Password Updated Successfully'); window.location.href = 'login.php';</script>";
            }
            else{
                echo "<script>alert('Please try again'); window.location.href = 'forget.php';</script>";
            }
        }
        else{
            echo "<script>alert('Password doesn't matched'); window.location.href = 'forget1.php';</script>";
        }


    }