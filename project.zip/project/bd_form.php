<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Book Birthday party</title>
    
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">


    <script type="text/javascript">
        function validateForm() {
            // Get form elements
            const titleInput = document.getElementById('title');
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');
            const numberInput = document.getElementById('number');
            const ageInput = document.getElementById('age');
            const dateInput = document.getElementById('date');
            const addressInput = document.getElementById('address');


            const name = nameInput.value.trim();
            const email = emailInput.value.trim();
            const number = numberInput.value.trim();
            const age = ageInput.value.trim();
            const date = dateInput.value.trim();
            const address = addressInput.value.trim();
            
            if (titleInput.selectedIndex === 0) {
                alert("Please select an Title");
                return false;
            }

            if (name === '') {
                alert('Please enter your name.');
                nameInput.focus();
                return false;
            }

            if (email === '') {
                alert('Please enter your email.');
                emailInput.focus();
                return false;
            } 
            else if (!isValidEmail(email)) {
                alert('Please enter a valid email address.');
                emailInput.focus();
                return false;
            }

            if (number === '') {
                alert('Please enter your Number.');
                numberInput.focus();
                return false;
            }
            else if(!isvalidNumber(number)) {
                alert('Please enter a valid Mobile Number.');
                numberInput.focus();
                return false;
            } 

            
            if (age === '') {
            alert('Please enter your age.');
            nameInput.focus();
            return false;
            }
            else if(age < 0 || age % 1 !== 0){
                alert("Age must be a positive integer.");
                return false;
            }
            else if(age < 1 || age > 100) {
                alert("Age must be between 1 and 100.");
                return false;
            }
            
            if (date === '') {
                alert('Please enter Date.');
                numberInput.focus();
                return false;
            }

            if (address === '') {
                alert('Please enter address.');
                numberInput.focus();
                return false;
            }

            return true;
        }

        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }

        function isvalidNumber(number) {
            const Regex = /^[0-9]{10}$/;
            return Regex.test(number);            
        }

        // function isValidAge(age) {
            
        // }
  
    </script>

  </head>
  <body>
    <!-- start navbar -->
        <?php
        include "nav.php";
        ?>
    <!-- end navbar -->

    <!-- start content -->
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh">
        <div class="border shadow p-3 rounded">
        <div class="mx-auto p-10 display-6" >
            <h3 class="card-title fw-bold">Birthday Party Reservation Form</h5>
        </div>
        <p class="border-bottom">Kindly fill the birthday party reservation form correctly to enable us to make advance plans to facilitate all required items.</p><br>
        <div class="mb-3 ">
        <!-- form -->
         <form method="post" action="chk_bd.php" onSubmit="return validateForm()">
            <label for="title" class="form-label">Title</label>
                <select class="form-select" name="title" id="title">
                    <option selected>Please Select</option>
                    <option value="mr">Mr.</option>
                    <option value="mrs">Mrs.</option>
                    <option value="ms">Ms.</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Full Name :</label>
                <input type="text" class="form-control" name="name" id="name">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email :</label>
                <input type="text" class="form-control" name="email" id="email">
            </div>
            <div class="mb-3">
                <label for="number" class="form-label">Mobile Number :</label>
                <input type="tel" class="form-control" name="number" id="number">
            </div>
            <div class="mb-3">
                <label for="age" class="form-label">Age :</label>
                <input type="number" class="form-control" name="age" id="age">
            </div>
            <div class="mx-auto p-10 display-6 ">
                <h5 class="card-title fw-bold border-bottom">Details About the Party</h5>
            </div>
            <div class="mb-3">
                <label for="date" class="form-label">Birthday Date and Time :</label>
                <input type="datetime-local" class="form-control" name="datetime" id="date">
            </div>
            <div class="mb-3">
            <label for="address" class="form-label">Address :</label>
            <textarea class="form-control" id="address" name="address" style="height: 100px"></textarea>
            </div>
            <div class="mb-3">
            <label for="request" class="form-label">Special Request :</label>
            <textarea class="form-control" id="request" name="request" style="height: 100px"></textarea>
            </div>
            <div class="d-grid gap-2 col-6 mx-auto">
            <input type="submit" value="submit" name="submit" class="btn btn-primary"><br>
            </div>
        </form>
        </div>
        </div>
        <!-- end form -->
    <!-- end content -->

    <!-- start footer -->
   <?php
    include "footer.php";
   ?>
    <!-- end footer -->
  </body>
</html>