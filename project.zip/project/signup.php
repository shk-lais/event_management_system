<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SignUp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">

    <script type="text/javascript">
      function validateForm() {
        // Get form elements
        const nameInput = document.getElementById('name');
        const emailInput = document.getElementById('email');
        const passwordInput = document.getElementById('password');
        const confirmPasswordInput = document.getElementById('cpassword');
        const selectInput = document.getElementById('select');

        const name = nameInput.value.trim();
        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();
        const confirmPassword = confirmPasswordInput.value.trim();

        if (name === '') {
          alert('Please enter your name.');
          nameInput.focus();
          return false;
        }

        if (email === '') {
          alert('Please enter your email.');
          emailInput.focus();
          return false;
          } else if (!isValidEmail(email)) {
          alert('Please enter a valid email address.');
          emailInput.focus();
          return false;
        }

        if (password === '') {
          alert('Please enter your password.');
          passwordInput.focus();
          return false;
        }

        if (password.length < 6) {
          alert('Password length must be at 6 character');
          passwordInput.focus();
          return false;
        }

        if (password !== confirmPassword) {
          alert('Passwords do not match. Please try again.');
          confirmPasswordInput.focus();
          return false;
        }
        if (selectInput.selectedIndex === 0) {
          alert("Please select an option");
          return false;
        }
        return true;
      }

      function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
      }
  
    </script>
  </head>
  <body>
   <!-- navbar -->
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php">MyEvent</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <ul class="nav justify-content-end">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">AboutUs</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login.php">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="signup.php">SignUp</a>
          </li>
        </ul>
      </div>
    </nav>
    <!-- end navbar -->
    <!-- content -->
    <div class="d-flex justify-content-center align-items-center" style="min-height: 100vh">
      <div class="border shadow p-3 rounded">
        <div class="d-flex justify-content-center mx-auto display-6">
          <h5 class="card-title fw-bold text-decoration-underline">Register</h5>
        </div>
        <!-- form -->
        <form method="post" action="chksign.php" name="frmsignup" onSubmit="return validateForm()">
          <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" id="name" placeholder="Name" name="name">
          </div>
          <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="text" class="form-control" id="email" placeholder="Email" name="email">
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" placeholder="Password" name="password">
          </div>
          <div class="mb-3">
            <label for="cpassword" class="form-label">Confirm Password</label>
            <input type="password" class="form-control" id="cpassword" placeholder="Confirm Password">
          </div>
          <div class="mb-3 ">
            <select class="form-select" aria-label="Default select example" id="select" name="role">
              <option selected  name="role">Select the Role</option>
              <option value="user">User</option>
              <option value="vendor">Vendor</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <input type="submit" class="btn btn-primary" value="Signup" name="submit">
          <!-- <button type="submit" class="btn btn-primary">SignUp</button> -->
          <a href="login.php" class="btn btn-link">Already Account</a>
        </form>
        <!-- end form -->
      </div>
    </div><!--end content-->
    <!-- start footer -->
    <?php
    include "footer.php";
    ?>
    <!-- end footer -->
  </body>
</html>
