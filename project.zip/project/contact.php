<?php

  $token=uniqid();

  include "conn.php";
  if($_POST['submit'])
  {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $msg=$_POST['message'];

    $sql="INSERT INTO contact VALUES('$name','$email','$subject','$msg','$token');";

    $result = mysqli_query($conn,$sql)or die("Connection failed: " .mysqli_error());

    if($result){
      echo "<script>alert('Thank You for Contacting us..!');</script>";
      echo "<script>alert('Team will contact you soon..!'); window.location.href = 'index.php';</script>";
    }else{
      echo "<script>alert('Please try again'); window.location.href = 'index.php';</script>";
    }
  }

?>