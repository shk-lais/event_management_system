<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Book Wedding event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">

    <script type="text/javascript">
        function validateForm() {
            // Get form elements
            const titleInput = document.getElementById('title');
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');
            const numberInput = document.getElementById('number');
            const bnameInput = document.getElementById('bname');
            const beduInput = document.getElementById('beducation');
            const gnameInput = document.getElementById('gname');
            const geduInput = document.getElementById('geducation');
            const dateInput = document.getElementById('date');
            const addressInput = document.getElementById('address');
            const btnInput = document.getElementById('photobtn');
            const wed_covInput = document.getElementById('wed_coverage');
            const budgetInput = document.getElementById('budget');


            const name = nameInput.value.trim();
            const email = emailInput.value.trim();
            const number = numberInput.value.trim();
            const bname = bnameInput.value.trim();
            const bedu = beduInput.value.trim();
            const gname = gnameInput.value.trim();
            const gedu = geduInput.value.trim();
            const date = dateInput.value.trim();
            const address = addressInput.value.trim();
            const photo = btnInput.value.trim();

            
            if (titleInput.selectedIndex === 0) {
                alert("Please select an Title");
                return false;
            }

            if (name === '') {
                alert('Please enter your name.');
                nameInput.focus();
                return false;
            }

            if (email === '') {
                alert('Please enter your email.');
                emailInput.focus();
                return false;
            } 
            else if (!isValidEmail(email)) {
                alert('Please enter a valid email address.');
                emailInput.focus();
                return false;
            }

            if (number === '') {
                alert('Please enter your Number.');
                numberInput.focus();
                return false;
            }
            else if(!isvalidNumber(number)) {
                alert('Please enter a valid Mobile Number.');
                numberInput.focus();
                return false;
            } 

            
            if (bname === '') {
                alert('Please enter Bride Name.');
                bnameInput.focus();
                return false;
            }
            
            if (bedu === '') {
                alert('Please enter Bride Education.');
                beduInput.focus();
                return false;
            }
            
            if (gname === '') {
                alert('Please enter Groom Name.');
                gnameInput.focus();
                return false;
            }
            
            if (gedu === '') {
                alert('Please enter Groom Education.');
                geduInput.focus();
                return false;
            }

            if (date === '') {
                alert('Please enter Date.');
                dateInput.focus();
                return false;
            }

            if (address === '') {
                alert('Please enter address.');
                addressInput.focus();
                return false;
            }

            if (photo === '') {
                alert('Please enter Photographer field.');
                btnInput.focus();
                return false;
            }

            if (wed_covInput.selectedIndex === 0) {
                alert("Please select Wedding Covrage");
                return false;
            }

            if (budgetInput.selectedIndex === 0) {
                alert("Please select Wedding Budget");
                return false;
            }

            return true;
        }

        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }

        function isvalidNumber(number) {
            const Regex = /^[0-9]{10}$/;
            return Regex.test(number);            
        }
  
    </script>

  </head>
  <body>
    <!-- start navbar -->
    <?php
    include "nav.php";
    ?>
    <!-- end navbar -->

    <!-- start content -->
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh">
        <div class="border shadow p-3 rounded">
        <div class="mx-auto p-10 display-6" >
            <h3 class="card-title fw-bold">Wedding Ceremony Reservation Form</h5>
        </div>
        <p class="border-bottom">Kindly fill the Wedding Ceremony reservation form correctly to enable us make advance plans to facilitate all required items.</p><br>
        <!-- form -->
        <form method="post" action="chk_wed.php" onSubmit="return validateForm()">
        <div class="mb-3 ">
            <label for="title" class="form-label">Title</label>
                <select class="form-select" name="title" id="title">
                    <option selected>Please Select</option>
                    <option value="mr">Mr.</option>
                    <option value="mrs">Mrs.</option>
                    <option value="ms">Ms.</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Full Name :</label>
                <input type="text" class="form-control" name="name" id="name" >
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email :</label>
                <input type="email" class="form-control" name="email" id="email" >
            </div>
            <div class="mb-3">
                <label for="number" class="form-label">Number :</label>
                <input type="tel" class="form-control" name="number" id="number" >
            </div><br>
            <!-- bride Information -->
            <p class="border-bottom fw-bold">Bride Information</p><br>
            <div class="mb-3">
            <label for="bname" class="form-label">Full Name :</label>
                <input type="text" class="form-control" name="bname" id="bname" >
            </div>
            <div class="mb-3">
            <label for="beducation" class="form-label">Education :</label>
                <input type="text" class="form-control" name="bedu" id="beducation" >
            </div>
            <br>
            <!-- Groom Information -->
            <p class="border-bottom fw-bold">Groom Information</p><br>
            
            <div class="mb-3">
            <label for="gname" class="form-label">Full Name :</label>
                <input type="text" class="form-control" name="gname" id="gname" >
            </div>
            <div class="mb-3">
            <label for="geducation" class="form-label">Education :</label>
                <input type="text" class="form-control" name="gedu" id="geducation" >
            </div>
            <br>
            <!-- more detail -->
            <p class="border-bottom fw-bold">More Detail about Wedding event</p><br>
            <div class="mb-3">
                <label for="date" class="form-label">Wedding Ceremony Date :</label>
                <input type="datetime-local" class="form-control" name="datetime" id="date" >
            </div>
            <div class="mb-3">
            <label for="address" class="form-label">Wedding Ceremony Address :</label>
            <textarea class="form-control" id="address" name="address" style="height: 100px" ></textarea>
            </div>
            <div class="mb-3 ">
            <label for="photo" class="form-label">Do you Need Photographer</label>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="photobtn" id="photo" value="yes">
            <label class="form-check-label" for="photo">
                Yes
            </label>
            </div>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="photobtn" id="photo" value="no">
            <label class="form-check-label" for="photo">
                No
            </label>
            </div>
            </div>
            <div class="mb-3 ">
            <label for="wed_coverage" class="form-label">How many Days of Ceremony</label>
                <select class="form-select" name="wed_day" id="wed_coverage">
                    <option selected>Please Select</option>
                    <option value="1">1-Day</option>
                    <option value="3">3-Days</option>
                    <option value="5">5-Days</option>
                    <option value="7">7-Days</option>
                    <option value="9">9-Days</option>
                </select>
            </div>
            <div class="mb-3 ">
            <label for="budget" class="form-label">Your Budget</label>
                <select class="form-select" name="wed_budget" id="budget">
                    <option selected>Please Select</option>
                    <option value="5">5 Lakhs</option>
                    <option value="10">10 Lakhs</option>
                    <option value="15">15 Lakhs</option>
                    <option value="20">20 Lakhs</option>
                    <option value="30">30 Lakhs</option>
                </select>
            </div>
            <div class="mb-3">
            <label for="request" class="form-label">Special Request :</label>
            <textarea class="form-control" id="request" name="request" style="height: 100px"></textarea>
            </div>
            <div class="d-grid gap-2 col-6 mx-auto">
            <input type="submit" value="submit" name="submit" class="btn btn-primary">
            </div>
        </form>
        </div>
        </div>
        <!-- end form -->
    <!-- end content -->

    <!-- start footer -->
    <?php
    include "footer.php";
    ?>
    <!-- end footer -->
  </body>
</html>