<!-- <?php

    session_start();
    include "conn.php";

    //  if($_POST["submit"]) 
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $email = $_POST['email'];
        $password = $_POST['password'];
        $role = $_POST['role'];

        $sql = "SELECT * FROM register WHERE email = '$email' AND password = '$password' AND role = '$role'";
        //echo $sql;
        $result=mysqli_query($conn,$sql) or die("Error in Query...");
        $count=mysqli_num_rows($result);

        if ($count > 0) {
            session_start();
            $row = $result->fetch_assoc();
            //echo $row["role"];
            $_SESSION['loggedin'] = true;
            // $_SESSION['email'] = $email;
            $_SESSION['token'] = $row['uid'];
            $_SESSION['role'] = $row['role'];
            
            
            //login according to role

            if ($row["role"] == "admin") {
                //echo "In Role Admin";
                header('location:admin/adminhome.php');
                exit();
            }
            else if($row["role"] =="vendor") {
                header("location:vendor/vendorhome.php");
            }
            else {
                header("Location:userhome.php");
            }
        } 
        else {
            // If the user is not found in the database, display an error message and redirect to index page.
            echo "<script>alert('Please try again'); window.location.href = 'login.php';</script>";
        }
    }
    

?> -->

<!-- <?php
    session_start();
    include "conn.php";

    $login=false;

    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $email = $_POST['email'];
        $password = $_POST['password'];
        $role = $_POST['role'];

        $sql = "SELECT * FROM register WHERE email = '$email' AND password = '$password' AND role = '$role'";

        $result=mysqli_query($conn,$sql) or die("Error in Query...");
        $count=mysqli_num_rows($result);

        if($count>0){
            session_start();
            $login==true;
            $_SESSION['loggedin']=true;
            $_SESSION['email']=$email;
            $_SESSION['password']=$password;
            $_SESSION['uid'] = $row['uid'];
            $_SESSION['role'] = $row['role'];

            if ($row["role"] == "admin") {
                //echo "In Role Admin";
                header('location:admin/adminhome.php');
                exit();
            }
            else if($row["role"] =="vendor") {
                header("location:vendor/vendorhome.php");
            }
            else {
                header("Location:userhome.php");
            }
        }else{
            echo "<script>alert('Please try again'); window.location.href = 'login.php';</script>";
        }


    }

?> -->

<?php
session_start();

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $sql = "SELECT * FROM register WHERE email = '$email' AND password = '$password' AND role = '$role'";
    $result=mysqli_query($conn,$sql) or die("Error in Query...");
        $count=mysqli_num_rows($result);


        if ($count>0) {
        $_SESSION['email'] = $email;
        $_SESSION['role'] = $role;
        $_SESSION['login'] = true;

        if ($role === 'user') {
            header("Location: userhome.php");
        } elseif ($role === 'vendor') {
            header("Location: vendor/vendorhome.php");
        } elseif ($role === 'admin') {
            header("Location: admin/adminhome.php");
        }
        exit();
    } else {
        $_SESSION['login_error'] = "Invalid email or password.";
        header("Location: login.php");
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
?>

