<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Delete Event</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">
        <style>
          .sidenav {
            width: 200px; 
            background-color: #f1f1f1;
            height: 100%; 
            position: fixed; 
            overflow: auto; 
          }

    
          .sidenav a {
            padding: 16px; 
            text-decoration: none; 
            display: block; 
          }

   
          .sidenav a:hover {
            background-color: #ddd;
          }

          .grid-container {
            display: grid;
            grid-template-columns: 1fr; 
            grid-gap: 10px; 
          }
    
          .grid-item {
            background-color: #ddd;
            padding: 20px;
            text-align: center;
          }
        </style>
        <script>
            function validateForm(){
                const tokenInput = document.getElementById('token');
                const selectInput = document.getElementById('select');

                const token = tokenInput.value.trim();

                if (selectInput.selectedIndex === 0) {
                    alert("Please select an option");
                    return false;
                }

                if (token === '') {
                    alert('Please enter token no.');
                    tokenInput.focus();
                    return false;
                }

                return true;
            }
        </script>
    </head>
    <body>
           
        <?php
        include "nav.php";
        ?>

    <div class="sidenav">
    <a class="nav-link" href="view_evnt.php">Birthday</a>
        <a class="nav-link" href="view_evnt.php">wedding</a>
        <a class="nav-link" href="view_evnt.php">seminar</a>
        <a class="nav-link" href="view_evnt.php">anniversary</a>
        <a class="nav-link" href="del_evnt.php">Delete Event</a>
  </div>
  <!-- Content area -->
  <div style="margin-left: 200px; padding: 16px;">
    <div class="grid-container">
    <div class="grid-item">
    <form action="del_evnt1.php" method="post" onSubmit="return validateForm()">
        <div class="mb-3">
            <select class="form-select" id="select" name="role">
                <option selected>Choose Event Type</option>
                <option value="birthday">Birthday</option>
                <option value="wedding">Wedding</option>
                <option value="seminar">Seminar</option>
                <option value="anniversary">Anniversary</option>
            </select>
        </div>
        <div class="mb-3">
                <label for="token" class="form-label">Token No.</label>
                <input type="text" class="form-control" id="token" name=token>
            </div>
                    <div class="d-grid gap-2 col-6 mx-auto">
                        <br>
                        <input type="submit" name="submit" value="submit" class="btn btn-primary">
                        <br>
                    </div>
                </div>
            </div>
        </form>
  </div>
    </div>
  </div>
</body>
  </html> 