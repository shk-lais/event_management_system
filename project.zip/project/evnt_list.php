<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Book Event</title>
    
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">
  </head>
  <body>
     <!-- start navbar -->
     <?php
      include "nav.php";
     ?>
     <!-- end navbar -->

    <!-- start content -->

    <div class="d-flex justify-content-center mx-auto p-10 display-1">
  <h2>We Organise</h2>
</div>

<div class="d-flex justify-content-between mx-auto px-4">
  <div class="card" style="width: 18rem;">
    <img src="image/img_bd_1.jpg" class="card-img-top">
    <div class="card-body">
      <h5 class="card-title fw-bold text-decoration-underline">Birthday</h5><br>
      <p class="card-text">A birthday is a special day that celebrates the anniversary of a person's birth. It is often marked by festive celebrations, including parties, gifts, and well wishes from family and friends.</p><br><br>
      <a href="bd_form.php" class="btn btn-primary">Book Event</a>
    </div>
  </div>

  <div class="card" style="width: 18rem;">
    <img src="image/img_w_1.jpg" class="card-img-top">
    <div class="card-body">
      <h5 class="card-title fw-bold text-decoration-underline">Wedding Ceremony</h5><br>
      <p class="card-text">A wedding is a beautiful and significant ceremony that marks the union of two people in marriage. It is a joyous occasion that brings together family and friends to celebrate the love and commitment of the couple. </p><br>
      <a href="wedding_form.php" class="btn btn-primary">Book Event</a>
    </div>
  </div>

  <div class="card" style="width: 18rem;">
    <img src="image/img_s_1.jpeg" class="card-img-top">
    <div class="card-body">
      <h5 class="card-title fw-bold text-decoration-underline">Seminar</h5><br>
      <p class="card-text">A seminar is a type of educational gathering that provides a platform for individuals to discuss a specific topic or issue in-depth. Seminars can be conducted in various fields, including academics, business, and technology.</p><br><br><br><br>
      <a href="seminar_form.php" class="btn btn-primary">Book Event</a>
    </div>
  </div>
  
  <div class="card" style="width: 18rem;">
    <img src="image/img_a_1.jpg" class="card-img-top">
    <div class="card-body">
      <h5 class="card-title fw-bold text-decoration-underline">Anniversary</h5><br>
      <p class="card-text">Anniversary are special occasions that mark important milestones in our lives. Whether it's a wedding anniversary, a work anniversary, or even the anniversary of a significant event, they provide us with an opportunity to reflect on the past and celebrate the present.</p><br><br>
      <a href="anniversary_form.php" class="btn btn-primary">Book Event</a>
    </div>
  </div>
</div>
    <!-- end content -->
   
    <!-- start footer -->
    <?php
    include "footer.php";
    ?>
    <!-- eng footer -->
  </body>