<?php
    include "conn.php";
    if($_POST['submit'])
    {
        $email=$_POST['email'];
        $role=$_POST['role'];

        $sql = "SELECT * FROM register WHERE email = '$email' AND role = '$role'";

        $result=mysqli_query($conn,$sql) or die("Error in Query...");
        // $count=mysqli_num_rows($result);

        if($result){
            echo '<html>
            <head>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">
            </head>';
            echo '<nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">MyEvent</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <ul class="nav justify-content-end">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="about.php">AboutUs</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="signup.php">SignUp</a>
            </li>
            </ul>
            </div>
            </nav>';
            echo '<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh">
            <div class="border shadow p-3 rounded">
            <form action="forget2.php" method="post">
            <div class="mb-3">
                <label for="pasd" class="form-label">New Password</label>
                <input type="text" class="form-control" name="pasd" id="pasd" required>
            </div>
            <br>
            <div class="mb-3">
            <label for="pasd1" class="form-label">Confirm New Password</label>
            <input type="text" class="form-control" name="pasd1" id="pasd1" required>
            </div>
            <input type="hidden" class="form-control" name="email">
            <div class="d-grid gap-2 col-6 mx-auto">
                <input type="submit" class="btn btn-primary" name="submit" value="Submit">
                <br>
            </div>
            </div>
            </div>';
        }else{
            header("Location:login.php");
        }
    }

?>