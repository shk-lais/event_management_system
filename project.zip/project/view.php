<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>View event</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">
        <style>
          .sidenav {
            width: 200px; 
            background-color: #f1f1f1;
            height: 100%; 
            position: fixed; 
            overflow: auto; 
          }

    
          .sidenav a {
            padding: 16px; 
            text-decoration: none; 
            display: block; 
          }

   
          .sidenav a:hover {
            background-color: #ddd;
          }

          .grid-container {
            display: grid;
            grid-template-columns: 1fr 1fr; 
            grid-gap: 10px; 
          }
    
          .grid-item {
            background-color: #ddd;
            padding: 20px;
            text-align: center;
          }
        </style>
    </head>
    <body>
           
        <?php
        include "nav.php";
        ?>

    <div class="sidenav">
    <a class="nav-link" href="view_evnt.php">Birthday</a>
        <a class="nav-link" href="view_evnt.php">wedding</a>
        <a class="nav-link" href="view_evnt.php">seminar</a>
        <a class="nav-link" href="view_evnt.php">anniversary</a>
        <a class="nav-link" href="del_evnt.php">Delete Event</a>
  </div>
  <!-- Content area -->
  <div style="margin-left: 200px; padding: 16px;">
    <div class="grid-container">
    <div class="grid-item">
    <?php

include "conn.php";


$sql = "SELECT * FROM birthday";
$result = mysqli_query($conn, $sql)or die("Connection failed: " .mysqli_error());

if ($result->num_rows > 0) {
    echo "<table border=2>
    <tr style=text-align:center>
    <th colspan=3 >BirthDay</th>
    </tr>
    <tr>
    <th>Name</th>
    <th>Token</th>
    <th>Approval</th>
    </tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
      echo "<tr>
      <td>".$row["name"]."</td>
      <td>".$row["token"]."</td>
      <td>".$row["approval"]."</td>
      </tr>";
    }
    echo "</table>";
  }?>
    </div>
    <div class="grid-item">
      <?php
      include "conn.php";
      $sql = "SELECT * FROM wedding";
      $result = mysqli_query($conn, $sql)or die("Connection failed: " .mysqli_error());

      if ($result->num_rows > 0) {
          echo "<table border=2>
          <tr style=text-align:center>
          <th colspan=3 >Wedding</th>
          </tr>
          <tr>
          <th>Name</th>
          <th>Token</th>
          <th>Approval</th>
          </tr>";
          // output data of each row
          while($row = $result->fetch_assoc()) {
            echo "<tr>
            <td>".$row["name"]."</td>
            <td>".$row["token"]."</td>
            <td>".$row["approval"]."</td>
            </tr>";
          }
          echo "</table>";
        }
      ?>
    </div>
    <div class="grid-item">
      <?php
      include "conn.php";
      $sql = "SELECT * FROM seminar";
      $result = mysqli_query($conn, $sql)or die("Connection failed: " .mysqli_error());

      if ($result->num_rows > 0) {
          echo "<table border=2>
          <tr style=text-align:center>
          <th colspan=3 >Seminar</th>
          </tr>
          <tr>
          <th>Name</th>
          <th>Token</th>
          <th>Approval</th>
          </tr>";
          // output data of each row
          while($row = $result->fetch_assoc()) {
            echo "<tr>
            <td>".$row["name"]."</td>
            <td>".$row["token"]."</td>
            <td>".$row["approval"]."</td>
            </tr>";
          }
          echo "</table>";
        }
      ?>
    </div>
    <div class="grid-item">
      <?php
      include "conn.php";
      $sql = "SELECT * FROM anniversary";
      $result = mysqli_query($conn, $sql)or die("Connection failed: " .mysqli_error());

      if ($result->num_rows > 0) {
          echo "<table border=2>
          <tr style=text-align:center>
          <th colspan=3 >Anniversary</th>
          </tr>
          <tr>
          <th>Name</th>
          <th>Token</th>
          <th>Approval</th>
          </tr>";
          // output data of each row
          while($row = $result->fetch_assoc()) {
            echo "<tr>
            <td>".$row["name"]."</td>
            <td>".$row["token"]."</td>
            <td>".$row["approval"]."</td>
            </tr>";
          }
          echo "</table>";
        }
      ?>
  </div>
    </div>
  </div>
</body>
  </html> 