<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>MyEvent</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Raleway:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <script type="text/javascript">
    function validateForm() {
            // Get form elements
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');
            const subjectInput = document.getElementById('subject');
            const messageInput = document.getElementById('message');

            const name = nameInput.value.trim();
            const email = emailInput.value.trim();
            const subject = subjectInput.value.trim();
            const message = messageInput.value.trim();
            
            if (name === '') {
            alert('Please enter your Name.');
            passwordInput.focus();
            return false;
            }

            if (email === '') {
            alert('Please enter your email.');
            emailInput.focus();
            return false;
            } else if (!isValidEmail(email)) {
            alert('Please enter a valid email address.');
            emailInput.focus();
            return false;
            }

            if (subject === '') {
            alert('Please write Subject.');
            passwordInput.focus();
            return false;
            }

            if (message === '') {
            alert('Please write Message.');
            passwordInput.focus();
            return false;
            }
            
            return true;
        }

        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }
  </script>
</head>

<body>

  <header id="header" class="header d-flex align-items-center">

    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
      <h1>MyEvent<span>.</span></h1>
      </a>
      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="login.php">LogIn</a></li>
          <li><a href="signup.php">SignUp</a></li>
        </ul>
      </nav><!-- .navbar -->
    </div>
  </header>
  <!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero">
    <div class="container position-relative">
      <div class="row gy-5" data-aos="fade-in">
        <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center text-center text-lg-start">
          <h2>Welcome to <span>MyEvent</span></h2>
          <p>In this platform we organize the event according to your choice</p>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <!-- <a href="evnt_list.php" class="btn-get-started">Book Event</a> -->
            <form action="chkevent.php" method="post">
              <input type="submit" class="btn-get-started" value="Book Event" name="book">
            </form>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2">
          <img src="assets/img/hero-img.svg" class="img-fluid" alt="" data-aos="zoom-out" data-aos-delay="100">
        </div>
      </div>
    </div>

    <div class="icon-boxes position-relative">
      <div class="container position-relative">
        <div class="row gy-4 mt-5">

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><img src="image/bday.png"></div>
              <h4 class="title">
                <!-- <a href="bd_form.php" class="stretched-link">Birthday</a> -->
                <form action="chkevent.php" method="post">
              <input type="submit" class="stretched-link" value="Birthday" name="book">
            </form>
              </h4>
            </div>
          </div><!--End Icon Box -->

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><img src="image/wedd.png"></div>
              <h4 class="title">
                <!-- <a href="wedding_form.php" class="stretched-link">Wedding</a> -->
                <form action="chkevent.php" method="post">
              <input type="submit" class="stretched-link" value="Wedding" name="book">
            </form>
              </h4>
            </div>
          </div><!--End Icon Box -->

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><img src="image/semi.png"></div>
            <form action="chkevent.php" method="post">
            <h4 class="title"><input type="submit" class="stretched-link" value="Seminar" name="book"></h4>
            </form>
            </div>
          </div><!--End Icon Box -->

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="icon-box">
              <div class="icon"><img src="image/anni.png"></div>
              <h4 class="title">
                <!-- <a href="anniversary_form.php" class="stretched-link">Anniversary</a> -->
                <form action="chkevent.php" method="post">
            <h4 class="title"><input type="submit" class="stretched-link" value="Anniversary" name="book"></h4>
            </form>
              </h4>
            </div>
          </div><!--End Icon Box -->

        </div>
      </div>
    </div>

    </div>
  </section>
  <!-- End Hero Section -->


  <!-- ====== main ======= -->
  <main id="main">

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>About Us</h2>
        </div>
        <div class="highlight-phone pt-4">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="intro">
                        <h2 class="fw-bold text-center">MyEvent</h2>
                        <p><br>This is the platform that allows organizers to post and promote their event in University. It is a revolutionary idea that can reduce lot of efforts of organizers of promoting their event, collecting statistics of event, getting the registrations done and handling payments. Not only this, it will make the process of registration lot easier for the participants too. It will be the single portal where students will be able to see every event, workshop, function or fest which is ongoing in university and with its notification system the website will make sure that they don't miss the event.&nbsp;<br><br><br></p>
                    </div>
                </div>
                <div class="col-sm-4">
                <img src="image/img_2.jpeg" class="img-fluid img-thumbnail">
                </div>
            </div>
        </div>
    </div>

      </div>
    </section><!-- End About Us Section -->
    <!-- ======= Our Team Section ======= -->
    <section id="team" class="team">
         <!-- about mentor -->
    <div class="team-boxed">
        <div class="container" data-aos="fade-up">
            <div class="intro">
                <div class="section-header">
                    <h2>Our Mentor</h2>
                </div>
            </div>
            <div class="row people" style="height: 400;width: 950;">
            <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title card-title fw-bold text-decoration-underline">Ms. Anita Pisote</h5>
                                <p class="card-text">Head of Department <br>( MCA)</p>
                            </div>
                        </div>
                </div>
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title card-title fw-bold text-decoration-underline">Ms. Supriya Lole</h5>
                            <p class="card-text">Professor<br>( MCA)</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- about mentor -->
    
    <!-- about team -->
    <div class="team-boxed pt-5">
        <div class="container" data-aos="fade-up"> 
            <div class="intro ">
            <div class="section-header">
                <h2>Our Team </h2>
            </div>
            </div>
            <div class="row">
                <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title card-title fw-bold text-decoration-underline">Lais Shaikh</h5>
                                <p class="description">Designer and Devloper</p>
                            </div>
                        </div>
                </div>
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title card-title fw-bold text-decoration-underline">Kaif Saeed Shaikh</h5>
                            <p class="description">Designer and Devloper</p>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </div>
            
    <!--  about team -->
      </div>
    </section><!-- End Our Team Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Contact</h2>
        </div>

        <div class="row gx-lg-0 gy-4">

            <form action="contact.php" method="post" role="form" class="php-email-form" onSubmit="return validateForm()">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="7" placeholder="Message" required></textarea>
              </div>
              <div class="text-center">
                <!-- <button type="submit">Send Message</button> -->
                <input type="submit" value="Send Message" name="submit">
            </div>
            </form>
          </div><!-- End Contact Form -->

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->
  <!-- end main -->

  <!-- ======= Footer ======= -->
  <?php
  include "footer.php";
  ?>
  <!-- End Footer -->

  <!-- JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>