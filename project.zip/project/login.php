<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>LogIn</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">

        <script type="text/javascript">
        function validateForm() {
            // Get form elements
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            const selectInput = document.getElementById('select');

            const email = emailInput.value.trim();
            const password = passwordInput.value.trim();
            
            if (email === '') {
            alert('Please enter your email.');
            emailInput.focus();
            return false;
            } else if (!isValidEmail(email)) {
            alert('Please enter a valid email address.');
            emailInput.focus();
            return false;
            }

            if (password === '') {
            alert('Please enter your password.');
            passwordInput.focus();
            return false;
            }
            
            if (selectInput.selectedIndex === 0) {
            alert("Please select an option");
            return false;
            }
            return true;
        }

        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }
  
    </script>
    
    
    </head>

    <body>
        <!-- navbar -->
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">MyEvent</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <ul class="nav justify-content-end">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">AboutUs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="signup.php">SignUp</a>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- end navbar -->

        <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh">
        <div class="border shadow p-3 rounded">
        <div class="d-flex justify-content-center mx-auto p-10 display-6">
            <h5 class="card-title fw-bold text-decoration-underline">LogIn</h5>
        </div>
          <!-- form -->
        <form method="post" action="chklogin.php" name="frmlogin" onSubmit="return validateForm()">
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="text" class="form-control" id="email" name=email>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name=password>
            </div>
            <div class="mb-3 ">
            <select class="form-select" id="select" name="role">
              <option selected  name="role">Select the Role</option>
              <option value="user">User</option>
              <option value="vendor">Vendor</option>
              <option value="admin">Admin</option>
            </select>
            </div>
            <div class="d-grid gap-2 col-6 mx-auto">
                <input type="submit" value=login class="btn btn-primary" name=submit>
            </div>
            <a href="signup.php" class="btn btn-link">Create an Account</a>
            <a href="forget.php" class="btn btn-link">Forget password</a>
        </form>
        </div>
        </div>
        <!-- end form -->

        <!-- start footer -->
        <?php
        include "footer.php";
        ?>
        <!-- end footer -->
    </body>
</html>
