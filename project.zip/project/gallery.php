<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Book Seminar Event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    
  <style>
    .gallery-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
    }

    .gallery-item {
      margin: 10px;
    }

    .gallery-item img {
      width: 200px;
      height: 150px;
      object-fit: cover;
      cursor: pointer;
    }
    .enlarged-image {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: rgba(0, 0, 0, 0.7);
      z-index: 9999;
      visibility: hidden;
      opacity: 0;
      transition: visibility 0s, opacity 0.3s;
    }

    .enlarged-image.show {
      visibility: visible;
      opacity: 1;
    }

    .enlarged-image img {
      max-width: 80%;
      max-height: 80%;
    }
  </style>
</head>
<body>
    <?php
        include "nav.php";    
    ?>
  <div class="gallery-container">
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-1.jpg" onclick="enlargeImage('assets/img/gallery/gallery-1.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-2.jpg" onclick="enlargeImage('assets/img/gallery/gallery-2.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-3.jpg" onclick="enlargeImage('assets/img/gallery/gallery-3.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-4.jpg" onclick="enlargeImage('assets/img/gallery/gallery-4.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-5.jpg" onclick="enlargeImage('assets/img/gallery/gallery-5.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-6.jpg" onclick="enlargeImage('assets/img/gallery/gallery-6.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-7.jpg" onclick="enlargeImage('assets/img/gallery/gallery-7.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-8.jpg" onclick="enlargeImage('assets/img/gallery/gallery-8.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-9.jpg" onclick="enlargeImage('assets/img/gallery/gallery-9.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-10.jpg" onclick="enlargeImage('assets/img/gallery/gallery-10.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-11.jpg" onclick="enlargeImage('assets/img/gallery/gallery-11.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-12.jpg" onclick="enlargeImage('assets/img/gallery/gallery-12.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-13.jpg" onclick="enlargeImage('assets/img/gallery/gallery-13.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-14.jpg" onclick="enlargeImage('assets/img/gallery/gallery-14.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-15.jpg" onclick="enlargeImage('assets/img/gallery/gallery-15.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-16.jpg" onclick="enlargeImage('assets/img/gallery/gallery-16.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-17.jpg" onclick="enlargeImage('assets/img/gallery/gallery-17.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-18.jpg" onclick="enlargeImage('assets/img/gallery/gallery-18.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-19.jpg" onclick="enlargeImage('assets/img/gallery/gallery-19.jpg')">
    </div>
    <div class="gallery-item">
      <img src="assets/img/gallery/gallery-20.jpg" onclick="enlargeImage('assets/img/gallery/gallery-20.jpg')">
    </div>
    <!-- Add more gallery items as needed -->
  </div>
  <div class="enlarged-image" onclick="closeEnlarged()">
    <img id="enlarged-img" src="" alt="Enlarged Image">
  </div>

  <script>
     function enlargeImage(src) {
      var enlargedImg = document.getElementById("enlarged-img");
      enlargedImg.src = src;
      var enlargedContainer = document.querySelector(".enlarged-image");
      enlargedContainer.classList.add("show");
    }

    function closeEnlarged() {
      var enlargedContainer = document.querySelector(".enlarged-image");
      enlargedContainer.classList.remove("show");
    }
  </script>

  <?php
    include "footer.php";
  ?>
</body>
</html>
