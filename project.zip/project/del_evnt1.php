<?php

    include "conn.php";

    if($_POST['submit'])
    {
        $event=$_POST['role'];
        $token=$_POST['token'];

        if($event=='birthday'){
            $sql = "DELETE FROM `birthday` WHERE `token` = '$token';";

            $result = mysqli_query($conn,$sql)or die("Connection failed: " .mysqli_error());

            if($result) {
                echo "<script>alert('Deleting Successfull'); window.location.href = 'view.php';</script>";
            }
            else{
                echo "<script>alert('Deleting Unsucessfull'); window.location.href = 'view.php';</script>";
            }
        }

        if($event=='wedding'){
            $sql = "DELETE FROM `wedding` WHERE `token` = '$token';";

            $result = mysqli_query($conn,$sql)or die("Connection failed: " .mysqli_error());

            if($result) {
                echo "<script>alert('Deleting Successfull'); window.location.href = 'view.php';</script>";
            }
            else{
                echo "<script>alert('Deleting Unsucessfull'); window.location.href = 'view.php';</script>";
            }
        }

        if($event=='seminar'){
            $sql = "DELETE FROM `seminar` WHERE `token` = '$token';";

            $result = mysqli_query($conn,$sql)or die("Connection failed: " .mysqli_error());

            if($result) {
                echo "<script>alert('Deleting Successfull'); window.location.href = 'view.php';</script>";
            }
            else{
                echo "<script>alert('Deleting Unsucessfull'); window.location.href = 'view.php';</script>";
            }
        }

        if($event=='anniversary'){
            $sql = "DELETE FROM `anniversary` WHERE `token` = '$token';";

            $result = mysqli_query($conn,$sql)or die("Connection failed: " .mysqli_error());

            if($result) {
                echo "<script>alert('Deleting Successfull'); window.location.href = 'view.php';</script>";
            }
            else{
                echo "<script>alert('Deleting Unsucessfull'); window.location.href = 'view.php';</script>";
            }
        }        
    }
?> 