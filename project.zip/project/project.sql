-- phpMyAdmin SQL Dump
-- version 5.1.4deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 21, 2023 at 02:37 PM
-- Server version: 8.0.33-0ubuntu0.22.10.2
-- PHP Version: 8.1.7-1ubuntu3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `anniversary`
--

CREATE TABLE `anniversary` (
  `title` varchar(5) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` int NOT NULL,
  `date` datetime NOT NULL,
  `address` text NOT NULL,
  `achoice` text NOT NULL,
  `request` text NOT NULL,
  `token` text NOT NULL,
  `approval` varchar(50) NOT NULL,
  `evnt_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `anniversary`
--

INSERT INTO `anniversary` (`title`, `name`, `email`, `number`, `date`, `address`, `achoice`, `request`, `token`, `approval`, `evnt_name`) VALUES
('1', 'ashu', 'user@test.com', 1111111111, '2023-05-20 18:53:00', '', 'wedding anniversary', '', '6469090348982', 'approved', 'anniversary'),
('1', 'ashu', 'user@test.com', 1111111111, '2023-05-31 03:55:00', '', 'Business Anniversary', '', '6469ce61b28d6', 'approved', 'anniversary'),
('1', 'ashu', 'user@test.com', 1111111111, '2023-05-31 06:48:00', '', 'Business Anniversary', '', '6469f70b28284', 'approved', 'anniversary'),
('1', 'ashu', 'user@test.com', 1111111111, '2023-05-30 06:49:00', 'asdf', 'wedding anniversary', '', '6469f75d5e322', 'pending', 'anniversary');

-- --------------------------------------------------------

--
-- Table structure for table `birthday`
--

CREATE TABLE `birthday` (
  `title` varchar(5) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` int NOT NULL,
  `age` int NOT NULL,
  `date` datetime NOT NULL,
  `address` text NOT NULL,
  `request` text NOT NULL,
  `token` text NOT NULL,
  `approval` varchar(50) NOT NULL,
  `evnt_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `birthday`
--

INSERT INTO `birthday` (`title`, `name`, `email`, `number`, `age`, `date`, `address`, `request`, `token`, `approval`, `evnt_name`) VALUES
('mr', 'ashu', 'user@test.com', 1111111111, 23, '2023-06-08 13:49:00', 'asdf', '', '6469081743324', 'approved', 'birthday'),
('mr', 'ashu', 'user@test.com', 1111111111, 23, '2023-05-31 03:52:00', 'asdf', '', '6469cde1d0507', 'approved', 'birthday');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `msg` text NOT NULL,
  `token` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `email`, `subject`, `msg`, `token`) VALUES
('ashu', 'admin@test.com', 'a', 'asdf', '646a46ab13b84');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `role` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`name`, `email`, `password`, `role`, `uid`) VALUES
('ashu', 'a@a.a', '111111', 'user', '646a5f221b051'),
('admin', 'admin@test.com', '111111', 'admin', '6468cb1fd6a94'),
('ashu', 'u@u.u', '111111', 'admin', '646a5f55e6a97'),
('user', 'user@test.com', '111111', 'user', '6468cae3d969d'),
('ashu', 'v@v.v', '111111', 'vendor', '646a5f3edbc1c'),
('vendor', 'vendor@test.com', '111111', 'vendor', '6468cb0bf0fe6');

-- --------------------------------------------------------

--
-- Table structure for table `seminar`
--

CREATE TABLE `seminar` (
  `title` varchar(5) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` int NOT NULL,
  `date` datetime NOT NULL,
  `address` text NOT NULL,
  `schoice` text NOT NULL,
  `request` text NOT NULL,
  `token` text NOT NULL,
  `approval` varchar(50) NOT NULL,
  `evnt_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `seminar`
--

INSERT INTO `seminar` (`title`, `name`, `email`, `number`, `date`, `address`, `schoice`, `request`, `token`, `approval`, `evnt_name`) VALUES
('mr', 'ashu', 'user@test.com', 1111111111, '2023-05-27 17:52:00', 'asdf', 'Health', '', '646908e9b3c0d', 'approved', 'seminar'),
('mr', 'ashu', 'user@test.com', 1111111111, '2023-05-30 03:54:00', 'asdf', 'Marketing', '', '6469ce3da85de', 'pending', 'seminar');

-- --------------------------------------------------------

--
-- Table structure for table `wedding`
--

CREATE TABLE `wedding` (
  `title` varchar(5) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `number` int NOT NULL,
  `bname` varchar(20) NOT NULL,
  `bedu` varchar(50) NOT NULL,
  `gname` varchar(50) NOT NULL,
  `gedu` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  `address` text NOT NULL,
  `photographer` varchar(5) NOT NULL,
  `wed_day` text NOT NULL,
  `wed_budget(lakh)` text NOT NULL,
  `request` text NOT NULL,
  `token` text NOT NULL,
  `approval` varchar(50) NOT NULL,
  `evnt_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wedding`
--

INSERT INTO `wedding` (`title`, `name`, `email`, `number`, `bname`, `bedu`, `gname`, `gedu`, `date`, `address`, `photographer`, `wed_day`, `wed_budget(lakh)`, `request`, `token`, `approval`, `evnt_name`) VALUES
('mr', 'ashu', 'user@test.com', 1111111111, 'b', 'bb', 'g', '', '2023-06-07 13:52:00', 'asdf', 'no', '5', '15', '', '646908cfa472b', 'approved', 'wedding'),
('mr', 'ashu', 'user@test.com', 1111111111, 'b', 'bb', 'g', '', '2023-06-05 06:52:00', 'asddf', 'yes', '3', '5', '', '6469f7ef04e14', 'pending', 'wedding'),
('mr', 'ashu', 'user@test.com', 1111111111, 'b', 'bb', 'g', '', '2023-06-05 06:52:00', 'asddf', 'yes', '3', '5', '', '6469f810adee5', 'pending', 'wedding'),
('mr', 'ashu', 'user@test.com', 1111111111, 'b', 'bb', 'g', 'gg', '2023-05-21 08:53:00', 'asd', 'yes', '3', '5', '', '6469f835f003b', 'pending', 'wedding');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD UNIQUE KEY `email` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
