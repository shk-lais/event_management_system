<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MyEvent</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">
  </head>
  <body>
    
<!-- start navbar -->
<?php
  include "nav.php";
?>
<!-- end navbar -->

<!-- slider -->
<div id="carouselExampleCaptions" class="carousel slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="image/img_2.jpeg" class="d-block w-100" >
    </div>
    <div class="carousel-item">
      <img src="image/img_1.jpg" class="d-block w-100">
    </div>
    <div class="carousel-item">
      <img src="image/img_3.jpg" class="d-block w-100">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<!-- end slider -->

<!-- content -->

<div class="d-flex justify-content-center mx-auto p-10 display-1">
  <h2>We Organise</h2>
</div>

<div class="d-flex justify-content-between mx-auto px-4">
  <div class="card" style="width: 18rem;">
    <img src="image/img_bd_1.jpg" class="card-img-top">
    <div class="card-body">
      <h5 class="card-title fw-bold text-decoration-underline">Birthday</h5><br>
      <p class="card-text">A birthday is a special day that celebrates the anniversary of a person's birth. It is often marked by festive celebrations, including parties, gifts, and well wishes from family and friends.</p><br><br>
      <a href="bd_form.php" class="btn btn-primary">Book Event</a>
    </div>
  </div>

  <div class="card" style="width: 18rem;">
    <img src="image/img_w_1.jpg" class="card-img-top">
    <div class="card-body">
      <h5 class="card-title fw-bold text-decoration-underline">Wedding Ceremony</h5><br>
      <p class="card-text">A wedding is a beautiful and significant ceremony that marks the union of two people in marriage. It is a joyous occasion that brings together family and friends to celebrate the love and commitment of the couple. </p><br>
      <a href="wedding_form.php" class="btn btn-primary">Book Event</a>
    </div>
  </div>

  <div class="card" style="width: 18rem;">
    <img src="image/img_s_1.jpeg" class="card-img-top">
    <div class="card-body">
      <h5 class="card-title fw-bold text-decoration-underline">Seminar</h5><br>
      <p class="card-text">A seminar is a type of educational gathering that provides a platform for individuals to discuss a specific topic or issue in-depth. Seminars can be conducted in various fields, including academics, business, and technology.</p><br><br><br><br>
      <a href="seminar_form.php" class="btn btn-primary">Book Event</a>
    </div>
  </div>
  
  <div class="card" style="width: 18rem;">
    <img src="image/img_a_1.jpg" class="card-img-top">
    <div class="card-body">
      <h5 class="card-title fw-bold text-decoration-underline">Anniversaries</h5><br>
      <p class="card-text">Anniversaries are special occasions that mark important milestones in our lives. Whether it's a wedding anniversary, a work anniversary, or even the anniversary of a significant event, they provide us with an opportunity to reflect on the past and celebrate the present.</p><br><br>
      <a href="anniversary_form.php" class="btn btn-primary">Book Event</a>
    </div>
  </div>
</div>

<!-- end content -->

<!-- know more content -->

<div class="d-flex justify-content-center mx-auto p-10 display-3">
  <h2>Know More</h2>
</div>

<div class="row px-4">
  <div class="col-sm-6 mb-3 mb-sm-0">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">About Us</h5><br>
        <p class="card-text">Know our mission, Team and Mentor</p><br>
        <a href="about.php" class="btn btn-link">know more</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Gallery</h5>
        <p class="card-text"></p><br>
        <a href="gallery.php" class="btn btn-link">know more</a>
      </div>
    </div>
  </div>
</div>
<!-- end know more content -->

<!-- footer -->
<?php
include "footer.php";
?>
<!-- end footer -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>