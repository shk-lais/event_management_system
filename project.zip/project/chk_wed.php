<?php

    include "conn.php";

    $token = uniqid();
    $approval = "pending";
    $evnt_name = "wedding";

    if($_POST['submit'])
    {
        $title=$_POST['title'];
        $name=$_POST['name'];
        $email=$_POST['email'];
        $number=$_POST['number'];
        $bname=$_POST['bname'];
        $bedu=$_POST['bedu'];
        $gname=$_POST['gname'];
        $gedu=$_POST['gedu'];
        $date=$_POST['datetime'];
        $address=$_POST['address'];
        $photo=$_POST['photobtn'];
        $day=$_POST['wed_day'];
        $budget=$_POST['wed_budget'];
        $requst=$_POST['request'];

        
        $sql="INSERT INTO wedding VALUES('$title','$name','$email','$number','$bname','$bedu','$gname','$gedu','$date','$address','$photo','$day','$budget','$requst','$token','$approval','$evnt_name');";
        // echo $sql;

        $result = mysqli_query($conn,$sql)or die("Connection failed: " .mysqli_error());
        
        if($result) {
            echo "<script>alert('Your form has been submitted.'); window.location.href = 'view.php';</script>";
            //echo "<script>alert('Vendor will contact you soon.'); window.location.href = 'view.php';</script>";
            // echo "inserted";
        }
        else{
            echo "<script>alert('Your form is not submitted.'); window.location.href = 'bd_form.php';</script>";
        }
    }

?>